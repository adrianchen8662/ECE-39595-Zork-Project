//this file will store all the commands for movement and actions

//which command was run, accepts string from input and picks out the command needed
void whichCommand() {

}

void moveCommand() {

}

void inventoryCommand() {

}

void takeCommand() {

}

void openCommand() {

}

void exitCommand() {

}

void readCommand() {

}

void dropCommand() {

}

void putCommand() {

}

void turnOnCommand() {

}

void attackCommand() {

}

